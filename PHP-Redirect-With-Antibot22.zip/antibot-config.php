<?php
/**
 * @Author: Nokia 1337
 * @Date:   2019-09-30 10:55:56
 * @Last Modified by:   Nokia 1337
 * @Last Modified time: 2019-10-26 03:37:17
*/

$config['apikey'] 		= '40b4e226f1069aa45fa8520f422181fa';  // https://antibot.pw/dashboard/developers